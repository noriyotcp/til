def do_loop():
    for i in range(10):
        print(i)

def main():
    # Your code here
    do_loop()

if __name__ == "__main__":
    main()