# CHANGELOG.md

## April 6, 2020
updating Minimist

## 1.0.0 (unreleased)

Features:

- disabled amp-jekyll to Gemfile
- added jekyll-redirect-from to Gem File
- author pictures are 250x250px
