---
layout: contact-form
title: "Contact Us"
author_profile: false
permalink: /contact/
redirect_from: /table/
suggestedcitiation: false
---

- **Email:** [contact@doctrineofdiscovery.org](mailto:contact@doctrineofdiscovery.org)
- **Web:** [doctrineofdiscovery.org](https://doctrineofdiscovery.org)
