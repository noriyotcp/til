---
title: All posts in the Papal Bulls category
layout: category
permalink: /categories/papal-bulls/
taxonomy: Papal-Bulls
redirect_from:
  - /bullsmain.htm
suggestedcitiation: false  
---

## Papal Bulls Articles
