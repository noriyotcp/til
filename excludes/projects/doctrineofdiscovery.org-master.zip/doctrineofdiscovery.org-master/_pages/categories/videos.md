---
title: Blog
layout: category
permalink: /categories/videos/
taxonomy: Videos
suggestedcitiation: false
--- 
  