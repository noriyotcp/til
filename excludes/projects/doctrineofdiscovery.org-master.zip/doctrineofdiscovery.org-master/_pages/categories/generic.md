---
title: Blog
layout: category
permalink: /categories/generic/
taxonomy: generic
suggestedcitiation: false
--- 
  