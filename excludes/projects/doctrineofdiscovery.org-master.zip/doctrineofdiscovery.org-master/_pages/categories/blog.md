---
title: Blog
layout: category
permalink: /categories/blog/
taxonomy: Blog
author_profile: false
suggestedcitiation: false
---
https://doctrineofdiscovery.org/tags/#featured