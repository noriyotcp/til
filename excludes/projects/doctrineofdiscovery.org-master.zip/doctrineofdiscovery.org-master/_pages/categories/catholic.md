---
title: All posts in the Catholic category
layout: category
permalink: /categories/catholic/
taxonomy: Catholic
author_profile: false
suggestedcitiation: false
---

## Catholic  Articles
