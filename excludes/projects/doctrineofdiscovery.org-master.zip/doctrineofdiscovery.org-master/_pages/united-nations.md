---
ID: 8841
title: "United Nations"
header:
  image: assets/images/united-nations-hq-by-basil-d-soufi-min.jpg
  caption: "United Nations General Assembly Hall in the UN Headquarters, New York. Photo credit, Basil D Soufi."
author: indigenous-values-initiative
permalink: /united-nations/
redirect_from: "/un/"
published: true
date: 2018-07-30 17:43:58
categories:
  - UN
  - United-Nations
  - Main
tags:
  - UN
  - United-Nations
  - Featured
---
## United Nations Declaration on the Rights of Indigenous Peoples and State of the World’s Indigenous Peoples.
<!--more-->

* [United Nations Declaration on the Rights of Indigenous Peoples](/united-nations-declaration-on-the-rights-of-indigenous-peoples/)
* [State of the World’s Indigenous Peoples](/sowip/)
* [Tonya Gonella Frichner, Preliminary study of the impact on Indigenous peoples of the international legal construct known as the Doctrine of Discovery.  ](/resources/law/preliminary-study-impact-doctrine-discovery-UN/)
