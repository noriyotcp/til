---
title: Give
author_profile: false
permalink: /give/
suggestedcitiation: false
---
# Give to the Doctrine of Discovery Healing fund.

> “Christians today need to put in the same amount of money and energy in the restoration and healing of Indigenous Peoples and their lands as they have put in to our destruction.” ~ Jake Edwards (Onondaga Nation)

<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top"><input name="cmd" type="hidden" value="_s-xclick" />
<input name="hosted_button_id" type="hidden" value="4HBQY356GD7C2" />
<input alt="PayPal - The safer, easier way to pay online!" name="submit" src="https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif" type="image" />
<img src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" alt="" width="1" height="1" border="0" /></form>


We need to sustain this work and have therefore initiated the “Restoration and Healing” fund. Jake Edward’s quote at the top of this page is the remedy for the Doctrine of Christian Discovery (as Steve Newcomb urges us to call it). Consider making a regular contribution to this fund, and encourage your religious denomination, church, temple, community, order or group to do the same. Our organizing committee is comprised of volunteers and completely dedicated to furthering this work. Every dollar goes toward educating the general public on the continuing effects of this legacy. We will also help you to educate others in your areas and to work as allies with Indigenous Peoples around the world. It has already been suggested that this conference be a feature of the UN Permanent Forum on Indigenous Issues in New York next spring.
