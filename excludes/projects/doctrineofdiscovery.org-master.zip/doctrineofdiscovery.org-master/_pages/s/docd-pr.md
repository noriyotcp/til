---
sitemap: false
title: "Doctrine of Christian Discovery Podcast Press Release"
redirect_to: https://ow.ly/u1CG50QFErM
permalink: /s/docd-pr/
---