---
sitemap: false
title: "press release"
redirect_to: https://artsandsciences.syracuse.edu/religion/news/university-to-host-conference-that-addresses-legal-and-theological-theory-of-the-doctrine-of-christian-discovery/
permalink: /s/press-release/
---
