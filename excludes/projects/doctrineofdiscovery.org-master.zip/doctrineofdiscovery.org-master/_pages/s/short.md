---
sitemap: false
title: "Doctrine of Christian Discovery"
redirect_to: https://goodfaithmedia.org/doctrine-of-christian-discovery/
permalink: /s/short/
---