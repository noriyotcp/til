---
title: Thank you
author_profile: false
permalink: /thank-you/
suggestedcitiation: false
---

Thank you for contacting the [_Doctrine of Discovery Project_](/) we will get back to you as soon as we are able.

We appreciate your email.
