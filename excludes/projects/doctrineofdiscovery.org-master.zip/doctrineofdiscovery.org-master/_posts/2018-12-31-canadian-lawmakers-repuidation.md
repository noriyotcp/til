---
ID: 9532
title: "Canadian Lawmakers call on Pope to Apologize"
excerpt: "Read the Canadian lawmakers letter to the pope."
date: 2018-12-31 14:54:46
published: true
categories:
  - Repudiations
tags:
  - Christian
  - Catholic
  - Repudiations
  - Canada
---
## In 2018 Canadian Lawmakers Requested an official apology from the Pope

* ["Request for an Official Papal Apology."](http://www.foxnews.com/politics/2018/05/02/canadian-lawmakers-seek-papal-apology-for-forced-schooling-indigenous-children.html)
