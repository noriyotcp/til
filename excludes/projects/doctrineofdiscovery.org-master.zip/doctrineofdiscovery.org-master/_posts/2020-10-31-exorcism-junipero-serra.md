---
title: "An Exorcism, Junipero Serra, and the Papal Bulls"
date: 2020-10-31T14:54:46
categories:
  - Blog
tags:
  - link
  - law
  - federal-Indian-law
link: http://originalfreenations.com/an-exorcism-junipero-serra-and-the-papal-bulls/
author: steven-newcomb
excerpt: "Archbishop Cordileone said his ceremony was intended to drive out evil and defend the image of Serra."
---
> Historian David Stannard, in _American Holocaust_ (1992), called the missions “furnaces of death.” The reason is that the Native population of an estimated 300,000 Native people when Serra first arrived, collapsed fifty percent to 150,000 Native people by 1834, a period of a mere sixty five years.
>
> This death toll is the context for the toppling of the statue of Serra who entered the Kumeyaay Nation territory when he first arrived in 1769\. From a Native viewpoint, that statue stood as a monument to the heinous tradition of the Spanish Catholic mission system which resulted in so much death and destruction.
