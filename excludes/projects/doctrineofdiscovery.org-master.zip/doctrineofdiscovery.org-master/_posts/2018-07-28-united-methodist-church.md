---
ID: 8959
title: "United Methodist Church Repudiates the Doctrine of Discovery"
author: umc
excerpt: "Trail of Repentance And Healing."
permalink: /united-methodist-church/
published: true
date: 2018-07-28 02:35:53
categories:
  - Faith-Communities
  - Repudiations
tags:
  - Repudiations
  - Christian
  - Methodist
  - UMC
redirect_from:
  - /8959/
---
*   [Petition 20831 United Methodist Church (⤓ PDF download)](/assets/pdfs/20831-GM-9999.pdf)
*   [Giving Substance to Words. AOR 2012 (⤓ PDF download)](/assets/pdfs/Giving-Substance-to-Words.-AOR-2012.pdf)
*   [Trail of Repentance And Healing (⤓ PDF download)](/assets/pdfs/Trail-of-Repentance-and-Healing.pdf)
