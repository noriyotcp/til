---
ID: 8983
title: "United Church of Canada Repudiates the Doctrine of Discovery"
author: united-church-canada
excerpt: "We repudiate the Doctrine of Discovery, which asserted that lands belonged to the Christian powers that 'discovered' them."
permalink: /united-church-of-canada-repudiates-the-doctrine-of-discovery/
published: true
date: 2018-07-28 02:55:05
categories:
  - Faith-Communities
  - Repudiations
tags:
  - Repudiations
  - United-Church-Canada
  - Canada
  - Christianity
  - UCC
redirect_from:
  - /8983/
---
*   [Social Policies of The United Church of Canada: Doctrine of Discovery (⤓ PDF download)](/assets/pdfs/Doctrine-of-Discovery-2012-10-26-018.pdf)
*   [We repudiate the Doctrine of Discovery, which asserted that lands belonged to the Christian powers that “discovered” them (offsite)](https://www.united-church.ca/social-action/justice-initiatives/doctrine-discovery).
*   [Doctrine of Discovery Background (⤓ PDF download)](/assets/pdfs/Doctrine-of-Discovery-2012-10-26-018.pdf)
*   [Indigenous Justice Archive of the UCC (offsite)](https://united-church.ca/social-action/justice-initiatives/reconciliation-and-indigenous-justice)
*   [The Children Remembered Archival project](http://thechildrenremembered.ca/)
