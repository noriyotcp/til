---
title: "Truth and Justification: On the Cruelties Against Indigenous People"
date: 2021-09-23T14:54:46
categories:
  - link
tags:
  - link
  - Haudensoaunee
  - sovereignty
  - TheyWereChildren
author: aila
link: https://www.thenation.com/article/society/indigenous-residential-boarding-schools-canada/
---
And yet, all across Mother Earth, stories reverberate of Indigenous nations and peoples’ resistance and refusal in the face of the settler colonial state. We know that each day is a gift from the Creator and every day we start by giving thanks to the Creator, to our Earth, and to all of creation. We give gratitude to the children of Turtle Island who were sent to “Indian residential schools.” We give gratitude to those who died in those schools, including those who died running away from these institutes of death and destruction. We give gratitude to those who survived these “schools” and came home. One of the most important teachings of the Haudenosaunee Confederacy is the seven-generation principle. Everything we do is to make the world a better place for the seven generations to come. We say, “NYA•WEÑHA SKÄ•NOÑH”: Thank you for being well.
  
