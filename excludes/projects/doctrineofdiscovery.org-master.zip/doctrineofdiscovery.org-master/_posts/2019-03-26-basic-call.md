---
ID: 9536
title: "Basic Call to Consciousness"
author: adam-dj-brett
excerpt: "Basic Call to Consciousness copies are available in English and Spanish."
permalink: /basic-call/
published: true
date: 2019-03-26 03:47:22
categories:
  - Resources
tags:
  - Books
  - Education
  - Indigenous-Peoples
  - resources
  - basic-call-to-consciousness
---

- _Basic Call to Consciousness_, edited by _Akwesane Notes_. Position papers delivered to the Non-Governmental Organization of the United Nations in Geneva in 1977 describe oppression of Native peoples in the US.

Copies in English and Spanish are available for sale from [Indigenous Values Initiative](https://indigenousvalues.org). Email [info@indigenousvalues.org](mailto:info@indigenousvalues.org)
