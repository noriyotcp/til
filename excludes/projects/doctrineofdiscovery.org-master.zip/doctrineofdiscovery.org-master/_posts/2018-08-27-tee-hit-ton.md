---
ID: 9468
title: "TEE-HIT-TON"
author: indigenous-values-initiative
excerpt: "Every America schoolboy knows that the savage tribes of this continent were deprived of their ancestral ranges by force and that, even when the Indians ceded millions of acres by treaty in return for blankets, food and trinkets, it was not a sale but the conquerors’ will that deprived them of their land"
permalink: /tee-hit-ton/
published: true
date: 2018-08-27 00:24:16
categories:
  - Law
tags:
  - law
  - US
  - US-Law
---
Excerpt:

> “Every America schoolboy knows that the savage tribes of this continent were deprived of their ancestral ranges by force and that, even when the Indians ceded millions of acres by treaty in return for blankets, food and trinkets, it was not a sale but the conquerors’ will that deprived them of their land.”  ( [_Id._, at 289-290](https://www.law.cornell.edu/supremecourt/text/348/272).)

* [Read the full The TEE-HIT-TON INDIANS, An Identifiable Group of Alaska Indians, Petitioner, v. The UNITED STATES Decision.](https://www.law.cornell.edu/supremecourt/text/348/272)
* [Back to Law](/law/).
