---
title: "Tadodaho on peace and the natural world"
categories:
  - Blog
  - quote
tags:
  - peace
  - religion
  - Haudenosaunee
  - quote
author: tadodaho
---
> “Peace can only be attained when human beings live in proper relationship to the natural world” ~ Tadodaho