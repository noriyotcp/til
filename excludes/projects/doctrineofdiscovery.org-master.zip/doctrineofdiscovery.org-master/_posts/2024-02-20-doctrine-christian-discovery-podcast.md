---
title: "Listsen to the Doctrine of Christian Discovery Podcast Now"
categories:
  - Blog
  - podcasts
tags:
  - link
  - press-release
  - podcast
  - doctrine
  - featured
link: https://goodfaithmedia.org/doctrine-of-christian-discovery/
---
Listen to the podcast on [Megaphone](https://goodfaithmedia.org/doctrine-of-christian-discovery/), [Spotify](https://open.spotify.com/show/4VnMhbq2UJbu3fdehsQ66I) or [Apple](https://podcasts.apple.com/us/podcast/doctrine-of-christian-discovery/id1729219360).

<iframe style="border-radius:12px" src="https://open.spotify.com/embed/show/4VnMhbq2UJbu3fdehsQ66I?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>