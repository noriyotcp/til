---
title: "An Open Letter on 'Indian Residential Schools' by Betty Lyons"
date: 2021-02-02T14:54:46
categories:
  - link
tags:
  - link
  - Haudensoaunee
  - soverignty
  - TheyWereChildren
  - featured
author: betty-lyons
link: https://aila.ngo/an-open-letter-on-indian-residential-schools/
---
