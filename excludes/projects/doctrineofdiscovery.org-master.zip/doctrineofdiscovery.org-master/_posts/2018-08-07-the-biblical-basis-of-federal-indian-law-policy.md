---
ID: 9344
title: 'The Biblical Basis of Federal Indian Law Policy'
author: steven-newcomb
excerpt: "As bizarre as it may seem, today’s federal definitions of Indian title and Indian nationhood find their basis in the Old Testament covenant tradition. This tradition is premised on the idea of a “chosen people” who have a covenant (treaty) with their deity to take over and colonize certain lands that the deity promised them, in this case Indian lands."
permalink: /the-biblical-basis-of-federal-indian-law-policy/
published: true
date: 2018-08-07 19:25:57
categories:
  - Law
  - Christian
tags:
  - US
  - US-Law
  - Christian
  - Old-Testament
  - land
---

> As bizarre as it may seem, today’s federal definitions of Indian title and Indian nationhood find their basis in the Old Testament covenant tradition. This tradition is premised on the idea of a “chosen people” who have a covenant (treaty) with their deity to take over and colonize certain lands that the deity promised them, in this case Indian lands.

[Learn more about the Biblical basis for Federal "Indian" Law Policy](http://originalfreenations.com/the-biblical-basis-of-federal-indian-law-policy/)
From Steve Newcomb.
