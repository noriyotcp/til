---
title: "Louisiana’s Ten Commandment Truthiness"
categories:
  - Blog
tags:
  - link
  - colonialism
  - doctrine-of-discovery
link: https://goodfaithmedia.org/louisianas-ten-commandment-truthiness/
author: adam-dj-brett
---
> I watch and wonder if we are witnessing the (re)birth of a distinctly American religion. One that shares a kinship and affinity with prior permutations of American Protestantism but is now more nationalistic, sentimental and generically applicable. One that makes Christian Nationalism and Project 2025 all the more palatable.

[Louisiana’s Ten Commandment Truthiness - Good Faith Media](https://goodfaithmedia.org/louisianas-ten-commandment-truthiness/).