---
title: "“Revoke the Papal Bulls”: Our Response to the Vatican’s March 30 Statement on the Doctrine of Discovery"
categories:
  - Blog
tags:
  - link
  - news
  - papal-bulls
  - featured
author: steven-newcomb
link: https://originalfreenations.com/revoke-the-papal-bulls-our-response-to-the-vaticans-march-30-statement-on-the-doctrine-of-discovery/
---
>   Let us set the context for this discussion. The context begins with the free existence of our Native nations and peoples, extending back to the beginning of our time through our oral histories and traditions, *contrasted* with the system of domination that was carried by ship across the ocean and imposed on everyone and everything. From that starting point we end up with a non-Christian view-from-the-shore with our Ancestors looking out at the invading ships sailing from Western Christendom, and a view-from-the-ship perspective, with the colonizers moving toward our Ancestors with the intention of establishing the Christian empire's system of domination where it did not yet exist. Below we discuss the recent Vatican Statement on the Doctrine of Discovery with a view-from-the-shore perspective, while realizing that the Vatican officials wrote their statement with a view-from-the-ship (church) perspective.