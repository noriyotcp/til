---
ID: 1817
title: "Preliminary study of the impact on indigenous peoples of the international legal construct known as the Doctrine of Discovery"
date: 2018-07-23T14:54:46
author: betty-lyons
excerpt: "Preliminary study of the impact on indigenous peoples of the international legal construct known as the Doctrine of Discovery / submitted by the Special Rapporteur Tonya Gonella Frichner (Onondaga Nation), Executive Director American Indian Law Alliance"
published: true
categories:
  - Resources
  - Law
tags:
  - Haudenosaunee-Confederacy
  - Onondaga-Nation
  - Indigenous-Peoples
  - Indian-Law
  - UN
  - United-Nations
redirect_from:
  - /1817
---

[Preliminary study of the impact on Indigenous peoples of the international legal construct known as the Doctrine of Discovery (PDF ⤓)](/assets/pdfs/DoctrinePrelimStudy2010.pdf) submitted by the Special Rapporteur Tonya Gonella Frichner (Onondaga Nation), Executive Director American Indian Law Alliance
