---
title: "Challenging the Vatican Papal Bulls of DominationNOT"
categories:
  - Blog
tags:
  - link
  - video
  - vatican
  - Papal-Bulls
link: https://vimeo.com/906571533
author: steven-newcomb
---
<iframe src="https://player.vimeo.com/video/906571533?h=92a6bede6b" width="640" height="360" frameborder="0" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen></iframe>

<p><a href="https://vimeo.com/906571533">Challenging the Vatican Papal Bulls of Domination</a> from <a href="https://vimeo.com/originalfreenations">Original Free Nations Advocates</a> on <a href="https://vimeo.com">Vimeo</a>.</p>