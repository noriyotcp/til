---
date: 2024-08-07T12:27:30-04:00
last_modified_at: 2024-08-16T12:27:30-04:00
title: "Mapping the Dcotrine of Discovery Zotero Library"
categories:
  - Blog
tags:
  - link
  - colonialism
  - doctrine-of-discovery
  - citations
link: https://www.zotero.org/groups/5628442/mapping_the_doctrine_of_discovery
author: adam-dj-brett
---
* [Mapping the Dcotrine of Discovery Zotero Library](https://www.zotero.org/groups/5628442/mapping_the_doctrine_of_discovery)