---
title: "The Doctrine of Discovery's Disastrous Legacy by Antonia Malchik"
categories:
  - Blog
tags:
  - link
  - article
link: https://antonia.substack.com/p/the-doctrine-of-discoverys-disastrous
---
> Do you ever wonder how land comes to be privately owned? I wonder all the time. It’s the whole reason for this newsletter. I’m interested in other forms of ownership, too, but it’s land ownership that gnaws at me day in and day out. How can you wander at will, let your feet roam, if your path is constricted by roads built to serve cars on one side, and “No Trespassing” or “Private Property” signs backed by laws made to serve landowning classes on the other?