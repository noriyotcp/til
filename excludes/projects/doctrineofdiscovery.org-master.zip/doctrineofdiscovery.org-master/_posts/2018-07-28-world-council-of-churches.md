---
ID: 8970
title: "World Council of Churches Repudiates the Doctrine of Discovery"
author: wcc
excerpt: "WCC statement on the Doctrine of Discovery and its enduring impact on Indigenous Peoples."
permalink: /world-council-of-churches/
published: true
date: 2018-07-28 02:41:41
categories:
  - Faith-Communities
  - Repudiations
tags:
  - WCC
  - Repudiations
  - Christianity
  - World-Council-Churches
redirect_from:
  - /8970/
---
*   [World Council of Churches Statement on the Doctrine of Discovery and its enduring impact on Indigenous Peoples (⤓ PDF download)](/assets/pdfs/wcc-document-021712.pdf)
