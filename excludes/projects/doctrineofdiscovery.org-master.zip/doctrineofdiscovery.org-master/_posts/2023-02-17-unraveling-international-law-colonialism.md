---
title: "Unraveling the International Law of Colonialism:
The 200th Anniversary of Johnson v. M’Intosh"
categories:
  - link
tags:
  - link
  - conference
link: https://na.eventscloud.com/ereg/index.php?eventid=722437
suggestedcitiation: false
---
[![flyer](/assets/images/unravelingcolonialism_square_rev2.png)](https://na.eventscloud.com/ereg/index.php?eventid=722437)

Join us for a review and analysis of Johnson v. M'Intosh on the 200th anniversary of the decision, presented via webinar on March 10, 2023 7:30 am - 2:30 pm (MST) - Exact times will be announced

You will be sent a link to the webinar before it begins.