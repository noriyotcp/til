---
ID: 9455
title: "Haudenosaunee Host Doctrine of Discovery Gathering"
author: jim-kent
excerpt: "&quot; I think it’s something that people don’t really understand,&quot;  observes Betty Lyons, President and Director of the American Indian Law Alliance. &quot; They go about their daily lives and they do things and they don’t understand why they’re doing them and how much the Doctrine has affected everyone everywhere.&quot;"
permalink: /haudenosaunee-host-doctrine-of-discovery-gathering/
published: true
date: 2018-08-26 23:51:46
categories:
  - News
tags:
  - Onondaga-Nation
  - Haudenosaunee-Confederacy
  - Interview
  - Event
  - Conference
---
> “I think it’s something that people don’t really understand,” observes Betty Lyons, President and Director of the [American Indian Law Alliance](https://aila.ngo/). “They go about their daily lives and they do things and they don’t understand why they’re doing them and how much the Doctrine has affected everyone everywhere.”
&#8230;
“Really what we’re doing is bringing together people who did not get along in the recent past,” comments Phil Arnold. “What we’re trying to do is get Christian groups and other religious groups to put into the restoration and healing of Indigenous peoples, as much energy into that as they have in the past into their destruction. The idea was that they were a primitive and inferior group of people. They were hindering civilization and progress and so they were understood to be in the way.”

- [Read More at the Lakota Country Times (subscription)](https://www.lakotacountrytimes.com/articles/haudenosaunee-host-doctrine-of-discovery-gathering/)
