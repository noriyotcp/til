---
title: "How the Vatican encouraged the colonization of Indigenous lands – and enabled the Crown to keep them"
date: 2020-08-01-01T15:55:46
categories:
  - Blog
tags:
  - link
  - doctrine-discovery
link: https://www.theglobeandmail.com/canada/article-pope-visit-doctrine-of-discovery/
author: indigenous-values-initiative
---
>Beneath glowering portraits of Balboa, Cortez and other Spanish conquistadors, Mr. Newcomb pored over the familiar Latin phrases, many of which he’d memorized over 40 years of researching the doctrine. The archivist flipped over the document. It was mostly blank, but one phrase gave Mr. Newcomb a jolt: “To Win and Conquer the Indies.” The Vatican’s ambitions were revealed.

> “There was that domination pattern right from the beginning,” he [Newcomb] said. “The entire world order is still premised on this claim of domination.”
