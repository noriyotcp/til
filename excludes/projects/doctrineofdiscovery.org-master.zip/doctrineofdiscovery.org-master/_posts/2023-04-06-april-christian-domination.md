---
title: "Continuing Christian Domination: A Response To The Vatican’s Repudiation Of The Doctrine Of Discovery"
categories:
  - Blog
tags:
  - law
  - religion
  - Christianity
  - Catholic
  - Vatican
  - featured
link: https://www.aprilonline.org/continuing-christian-domination/
suggestedcitiation: false
---
When the Vatican finally comes to the realization it is mired in the genocidal mud of centuries of racist exploitation of Indigenous peoples around the world, a step towards acknowledging the need for reconciliation is welcome.

The [statement by the Vatican](https://press.vatican.va/content/salastampa/en/bollettino/pubblico/2023/03/30/230330b.html) repudiating the Doctrine of Discovery, issued March 30th, is important and is representative of decades of work by Indigenous and non-Indigenous activists who have fought an often-lonely battle across the globe to bring attention to the racist underpinnings that still define so much of the legal mechanisms used to deny Indigenous peoples their rightful standing among the nations of the world.