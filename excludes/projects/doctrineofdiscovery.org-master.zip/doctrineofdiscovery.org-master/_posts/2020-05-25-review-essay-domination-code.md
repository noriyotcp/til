---
ID: 9542
title: "REVIEW ESSAY The Doctrine of Discovery as a Doctrine of Domination"
author: indigenous-values-initiative
excerpt: "In JSRNC, independent scholar Joy Greenberg reviewed _Pagans in the Promised Land_ and _The Doctrine of Discovery: Unmasking the Domination Code_."
date: 2020-05-25 13:07:09
categories:
  - Resources
  - Education
tags:
  - film-analysis
  - Indigenous-Knowledges
  - Reviews
---

Greenberg, Joy, "REVIEW ESSAY: The Doctrine of Discovery as a Doctrine of Domination," in _JSRNC_ JSRNC 10.2 (2016), 236-244. doi: 10.1558/jsrnc.v10i2.28942.
[⤓ download as a pdf](/assets/pdfs/Greenberg--ReviewEssayDoctrineofDomination.Final.pdf) or [view on academia.edu](https://www.academia.edu/27450723/REVIEW_ESSAY_The_Doctrine_of_Discovery_as_a_Doctrine_of_Domination).

* [Watch _The Doctrine of Discovery: Unmasking the Domination Code_ on Vimeo](https://vimeo.com/ondemand/dominationcode). The film is
 a collaborative effort between Dakota filmmaker and Director Sheldon Wolfchild and Co-Producer Steven Newcomb (Shawnee, Lenape).
