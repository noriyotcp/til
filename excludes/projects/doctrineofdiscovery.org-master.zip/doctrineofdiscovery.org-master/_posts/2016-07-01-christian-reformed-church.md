---
ID: 1607
title: "Christian Reformed Church"
date: 2016-07-01T15:08:34
excerpt: "Read the Christian Reformed Church statement repudiating the Doctrine of Discovery."
published: true
author: christian-reformed
categories:
  - Repudiations
  - Faith-Communities
tags:
  - Evangelical
  - Protestant
  - Christian
  - PDF
  - Repudiations
redirect_from:
  - /1607/
---


>Synod 2016 responded to a study report on the Doctrine of Discovery by labelling the doctrine as heresy and lamenting the pain it has caused.

[Synod Repudiates Doctrine of Discovery](https://www.crcna.org/news-and-events/news/synod-repudiates-doctrine-discovery)

[Christian Reformed Church Doctrine of Discovery Task Force Document (PDF)](https://www.crcna.org/sites/default/files/doctrine_of_discovery.pdf)
