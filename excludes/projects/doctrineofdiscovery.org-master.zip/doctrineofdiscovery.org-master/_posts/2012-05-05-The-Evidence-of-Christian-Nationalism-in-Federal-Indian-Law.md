---
title: "The Evidence of Christian Nationalism in Federal Indian Law: The Doctrine of Discovery, Johnson v. McIntosh, and Plenary Power"
categories:
  - Blog
  - Resource
tags:
  - link
  - PDF
  - law
  - Nationalism
  - Christian-Nationalism
  - Indian-Law 
  - Christianity
  - Federal-Indian-Law 
  - Land-Rights
link: https://socialchangenyu.com/review/evidence-of-christian-nationalism-in-federal-indian-law-the-doctrine-of-discovery-johnson-v-mcintosh-and-plenary-power-the/
author: steven-newcomb
---
Newcomb, Steven T. "The Evidence of Christian Nationalism in Federal Indian Law: The Doctrine of Discovery, Johnson v. McIntosh, and Plenary Power." *NYU Rev. L. & Soc. Change* 20 (1992): 303. [Download PDF](/assets/pdfs/Steven-Newcomb_RLSC_20.2.pdf)