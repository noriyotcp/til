---
title: "Now Streaming: The Doctrine of Discovery: Unmasking the Domination Code"
date: 2020-12-09T14:54:46
header:
  image: /assets/images/doctrine-of-discovery-unmasking-domination-code.jpg
  caption: "Photo credit: Doctrine of Discovery: Unmasking the Domination Code, DVD Cover"
categories:
  - Blog
tags:
  - video
  - film
  - doctrine-discovery
  - featured
link: https://vimeo.com/ondemand/dominationcode
---
## Watch Now
[Now Streaming](https://vimeo.com/ondemand/dominationcode){: .btn .btn--warning .btn--x-large}

## Details
The iconic film _The Doctrine of Discovery: Unmasking the Domination Code_ is now streaming on Vimeo. You can rent or purchase the film. The film is a collaborative effort between Dakota filmmaker and Director Sheldon Wolfchild and Co-Producer Steven Newcomb (Shawnee, Lenape). You can learn more at [Original Free Nations](http://originalfreenations.com/)

