---
date: 2024-08-07T12:27:30-04:00
last_modified_at: 2024-08-16T12:27:30-04:00
title: "The Doctrine of Christian Discovery Podcast Zotero Library"
categories:
  - Blog
tags:
  - link
  - colonialism
  - doctrine-of-discovery
  - citations
link: https://www.zotero.org/groups/5628453/doctrine_of_christian_discovery_podcast
author: adam-dj-brett
---
* [The Doctrine of Christian Discovery Podcast Zotero Library](https://www.zotero.org/groups/5628453/doctrine_of_christian_discovery_podcast)