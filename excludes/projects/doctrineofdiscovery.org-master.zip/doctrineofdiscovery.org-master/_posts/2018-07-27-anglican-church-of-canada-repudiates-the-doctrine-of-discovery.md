---
ID: 8909
title: "Anglican Church of Canada Repudiates the Doctrine of Discovery"
author: adam-dj-brett
excerpt: "Anglican Church of Canada's statement repudiating the Doctrine of Discovery."
permalink: /anglican-church-of-canada-repudiates-the-doctrine-of-discovery/
published: true
date: 2018-07-27 11:18:09
categories:
  - Repudiations
  - Faith-Communities
tags:
  - anglican
  - Christian
  - PDF
  - Canada
  - Repudiations
redirect_from:
  - /8909/
---
* [Anglican Church of Canada's Statement on "Indian Residential Schools"](https://www.anglican.ca/tr/histories/)
* [Download the Anglican Church of Canada's statement (⤓ PDF)](/assets/pdfs/A086-R1-ACIP-Repudiate-the-Doctrine-of-Discovery.pdf "PDF")
