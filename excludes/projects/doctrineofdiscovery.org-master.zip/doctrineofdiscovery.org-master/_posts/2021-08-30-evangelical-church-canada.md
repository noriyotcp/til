---
title: "Evangelical Church in Canada"
date: 2021-08-30T14:54:46
last_modified_at: 2022-01-28T12:24:36
excerpt: "Read the Evangelical Church in Canada statement repudiating the Doctrine of Discovery."
published: true
categories:
  - Repudiations
  - Faith-Communities
tags:
  - Evangelical
  - Protestant
  - Christian
  - PDF
  - Repudiations
  - Canada
---
## In 2011 the Evangelical Church in Canada Repudiated the Doctrine of Discovery

*  [A Resolution Encouraging Right Relationships with Indigenous Peoples (PDF)](/assets/pdfs/2011ELCICResolutiononRightRelationshipswithIndigenousPeoples.pdf)
