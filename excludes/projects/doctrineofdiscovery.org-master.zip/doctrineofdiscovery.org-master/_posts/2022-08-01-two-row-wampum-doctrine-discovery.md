---
title: "The Two Row Wampum: a Repudiation of the Doctrine of Discovery"
date: 2022-08-01-01T14:54:46
categories:
  - Blog
tags:
  - link
  - doctrine-discovery
link: https://grandback.org/journal.php?id=the_two_row_wampum_a_repudiation_of_the_doctrine_of_discovery
author: indigenous-values-initiative
---
>In the Two Row Wampum, an agreement between two peoples, the Dutch were the first Europeans to sit down and negotiate with the Haudenosaunee Confederacy, doing so in 1613. The English followed suit in 1645, and then the French in 1701. All three of these European powers had colonies in North America at the time, and all three were signatories to the Two Row Wampum.

>The concept and agreement of the Two Row "Wampum law" repudiated the Doctrine of Discovery, an agreement that gave Christian explorers the right to claim lands they discovered and convert the inhabitants to Christianity under the threat of war.
