---
ID: 9474
title: "Haudenosaunee Democracy"
author: jim-kent
excerpt: "Academics, attorneys and religious leaders from as far away as Chile gathered at this site sacred to members of the Haudenosaunee Confederacy to discuss the Doctrine of Discovery."
permalink: /haudenosaunee-democracy/
published: true
date: 2018-08-27 11:16:28
categories:
  - News
tags:
  - Law
  - US-Law
  - Indigenous-Peoples
  - Haudenosaunee-confederacy
  - Onondaga-Nation
  - Conference
  - event
---
Excerpt:

> While visiting with President and Director of the [American Indian Law Alliance Betty Lyons](https://aila.ngo) prior to the start of the recent Haudenosaunee Doctrine of Discovery conference, I was advised that the United States would certainly be run a lot differently if it were part of that confederacy. “We would never allow in our nation what’s happening in the United States right now. Our women have the power to put our leaders up, and to take them down when they’re not doing their duties and responsibilities. So, all of those positions are not ones of power and prestige, they’re positions of responsibility.”

[Read More in the Lakota Times (Subscription)](https://www.lakotacountrytimes.com/articles/haudenosaunee-host-doctrine-of-discovery-gathering/)
