---
title: "'Political Principles and Indian Sovereignty': Lee Hester's Philosophical Critique of US Anti-Indian Law"
categories:
  - Blog
tags:
  - link
  - law
author: peter-derrico
link: https://peterderrico.substack.com/p/political-principles-and-indian-sovereignty
---
> The Supreme Court now avoids naming the doctrine, as if that makes the problem go away.

> Hester concludes that the labyrinth of “inherent and retained sovereignty under plenary power” obscures without resolving the fundamental and deepening issue: “Either Indians are or are not a part of the United States.”
> 
> The question is becoming increasingly difficult to answer.