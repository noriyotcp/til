---
ID: 9543
title: "Domination and the Murder of George Floyd"
author: steven-newcomb
excerpt: "In CounterPunch, Shawnee/Lenape scholar Steve Newcomb connects anti-blackness and racism to the domination and dehumanization of the Doctrine of Discovery."
date: 2020-05-25 13:07:09
categories:
  - News
  - Education
tags:
  - Black-Lives-Matter
  - Indigenous-Knowledges
---

- [→ Domination and the Murder of George Floyd - CounterPunch.org by Steve Newcomb](https://www.counterpunch.org/2020/06/04/domination-and-the-murder-of-george-floyd/)
- [Ways to support Black Lives Matter](https://blacklivesmatter.carrd.co/)
