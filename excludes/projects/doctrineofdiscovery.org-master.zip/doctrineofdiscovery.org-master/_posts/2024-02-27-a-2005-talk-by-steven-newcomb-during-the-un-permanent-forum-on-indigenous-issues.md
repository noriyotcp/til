---
title: "A 2005 Talk by Steven Newcomb During the UN Permanent Forum on Indigenous Issues"
categories:
  - Blog
tags:
  - link
  - video
  - un
link: https://stevennewcomb.substack.com/p/a-2005-talk-by-steven-newcomb-during
author: steven-newcomb
---

<iframe title="vimeo-player" src="https://player.vimeo.com/video/906827808?h=c65722002a" width="640" height="360" frameborder="0"    allowfullscreen></iframe>