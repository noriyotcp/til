---
title: "Did Pope Alexander VI Authorize England’s Colonization of North America?"
excerpt_separator: "<!--more-->"
categories:
  - Blog
tags:
  - link
  - Canopy
  - Johnson
  - featured
link: https://canopyforum.org/2023/03/21/did-pope-alexander-vi-authorize-englands-colonization-of-north-america/
date: 2023-03-18 01:54:46
author: matthew-cavedon
sidebar:
  - title: "Next Steps"
    image: /assets/images/colonial-contact.jpg
    image-alt: "Indigenous peoples on the left and European Christian colonizers on the right planting a cross. In the middle is Mother Earth."
    text: "Learn More about the Doctrine of Discovery"
    nav: next-steps 
---
English imperial adventurism did not begin with Alexander. It began with [King] Henry [VII] skirting or directly contradicting *Inter caetera*. Henry would not be the last Englishman to do so.