---
title: "Johnson v McIntosh & the Mental World of Domination
A Brief Video by Steven Newcomb and William Laronal, Jr."
categories:
  - Blog
tags:
  - link
  - video
link: https://stevennewcomb.substack.com/p/johnson-v-mcintosh-and-the-mental
author: steven-newcomb
---

[Transcript PDF](/assets/pdfs/Johnson-v-McIntosh-the-Mental-World-of-Domination_otter_ai.pdf)
