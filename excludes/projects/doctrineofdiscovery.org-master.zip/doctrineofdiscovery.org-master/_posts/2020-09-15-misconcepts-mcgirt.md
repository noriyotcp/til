---
ID: 9550
title: "Misconceptions About McGirt v. Oklahoma"
excerpt: "Federal Indian law displaces the historical ‘starting point’ — the original free existence of Native nations..."
date: 2020-09-01 14:54:46
categories:
  - Blog
tags:
  - link
  - law
link: https://blogs.umass.edu/derrico/2020/09/14/misconceptions-about-mcgirt-v-oklahoma/
author: peter-derrico
---

> The “many other legal doctrines” and the congressional “tools” are, like the “plenary power” put forth in Lone Wolf, all derivatives of “Christian discovery.” Gorsuch hid that fact in a cryptic citation to the 1868 Treatise on the American Law of Real Property by Emory Washburn. The Treatise discusses “the discovery and settlement of this country by Europeans.”

Some [Misconceptions About McGirt v. Oklahoma by Peter d’Errico](https://blogs.umass.edu/derrico/2020/09/14/misconceptions-about-mcgirt-v-oklahoma/).
