---
title: "Oak Flat and Pope Alexander VI’s Papal Decree of Domination in U.S. Law"
date: 2021-02-02T14:54:46
categories:
  - Blog
tags:
  - link
  - mascots
author: steven-newcomb
link: https://originalfreenations.com/oak-flat-and-pope-alexander-vis-papal-decree-of-domination-in-u-s-law/
---
>Steven Newcomb (Shawnee/Lenape) Prior to the invasion of this continent (“North America”) by representatives of the monarchs of Western Christendom, the original nations and peoples of the continent, such as the Apache, were living their own free and independent way of life. We can think back on the thousands of years during which no Christians prior to the invasion of this continent (“North America”) by representatives of the monarchs of Western Christendom, the original nations and peoples of the continent, such as the Apache, were living their own free and independent way of life.
