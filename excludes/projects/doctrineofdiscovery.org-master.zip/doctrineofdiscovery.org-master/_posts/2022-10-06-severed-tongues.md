---
title: "Tadodaho on language"
categories:
  - Blog
  - quote
tags:
  - language
  - Haudenosaunee
  - quote
author: tadodaho
---
> "They severed our tongues so we couldn’t speak our language then punished us for not being able to speak it." - Tadodaho