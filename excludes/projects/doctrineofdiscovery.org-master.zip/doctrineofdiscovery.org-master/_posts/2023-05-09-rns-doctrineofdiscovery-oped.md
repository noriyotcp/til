---
title: "Undoing the Christian nationalism of the Doctrine of Discovery"
categories:
  - Blog
tags:
  - link
  - oped
link: https://religionnews.com/2023/05/08/undoing-the-christian-nationalism-of-the-doctrine-of-discovery/
---
The repudiation, which came in a statement from a bureaucratic office, not Pope Francis himself, said the doctrine had been “manipulated” by colonizers “to justify immoral acts against Indigenous peoples that were carried out, at times, without opposition from ecclesial authorities.”

The native Americans also felt the statement downplayed the active role the Catholic Church took in driving the colonization and destruction of Indigenous populations.