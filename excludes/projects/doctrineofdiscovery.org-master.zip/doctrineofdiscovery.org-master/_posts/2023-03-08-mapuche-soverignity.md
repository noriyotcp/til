---
title: "Aucan Huilcaman: Chilean Constitutional Process and its Permanent Denial of the Mapuche Nation"
categories:
  - Blog
tags:
  - link
  - Chile
  - South-America
  - featured
link: https://redabyayala.blogspot.com/2023/03/aucan-huilcaman-chilean-constitutional.html
---
> The Chilean political class that converges in the Chamber of Deputies and Senators, not only continue to act in the "old political doctrine of denial of the Mapuche People and their rights", but also try to omit and ignore the "legal status" that currently available to Indigenous Peoples. This "legal status" comes from international law that has recognized: the "right of self-determination", the "Mapuche Parliaments", the "Territorial Sovereignty", the "Free and Informed Prior Consent", among other relevant rights that constitute the tools policies to decide whether or not to participate in a process that is clear and previously supervised and pre-established in its contents. In this case, we Mapuche have specifically decided not to participate. 

 