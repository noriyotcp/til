---
title: "The Original Cancel Culture"
date: 2021-01-05T14:54:46
categories:
  - Blog
tags:
  - link
  - mascots
author: betty-lyons
link: https://aila.ngo/the-original-cancel-culture/
---

> The idea that Chief Wahoo is somehow honoring Indigenous peoples and his removal is cancel culture is not only absurd but is the reinforcement of the mindset derived from the Doctrine of Discovery...
