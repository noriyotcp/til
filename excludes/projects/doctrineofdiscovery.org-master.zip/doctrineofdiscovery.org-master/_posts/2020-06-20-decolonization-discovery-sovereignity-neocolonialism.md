---
title: "Decolonization, Discovery, Sovereignty, and Neocolonialism"
categories:
  - Blog
tags:
  - link
  - Decolonization
  - Discovery
  - Sovereignity
  - neoclonilaism
link: https://youtu.be/ZUM6R5rMbss?si=V8qUeb-RtM0u9A-y
author: tupac-enrique-acosta
---
Featured speaker: Tupac Enrique Acosta, Tonatierra

This foundational decolonization webinar addresses the Doctrine of Discovery, the intersection between indigenous and environmental struggles, facing the challenges of neocolonialism (i.e., the US-Mexico-Canada Agreement (USMCA)) and the forced disappearance of the 43 Ayotzinapa students that remains in impunity.

Organized by the NLG Indigenous Peoples’ Rights Committee and the NLG Environmental Human Rights Committee