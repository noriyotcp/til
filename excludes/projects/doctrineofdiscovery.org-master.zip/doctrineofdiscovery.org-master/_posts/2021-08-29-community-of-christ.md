---
title: "Community of Christ"
date: 2021-08-29T14:54:46
excerpt: "Read the Community of Christ statement repudiating the Doctrine of Discovery."
published: true
categories:
  - Repudiations
  - Faith-Communities
tags:
  - Evangelical
  - Protestant
  - Christian
  - PDF
  - Repudiations

---
## In 2016 the Community of Christ Repudiated the Doctrine of Discovery

* [Renunciation of the Doctrine of Discovery (PDF)](/assets/pdfs/Community-of-Christ-Resolutions-WC2016.pdf)
