---
title: "Save the Date: Christian Domination & The Genocide of Turtle Island"
excerpt_separator: "<!--more-->"
header:
  image: /assets/images/church-red-analena-provost.jpg
  caption: "Art by Analena Provost"
date: 2023-04-12 13:54:46
categories:
  - Blog
tags:
  - Christianity
  - featured
  - conference
  - featured
suggestedcitiation: false
---
Please join us for panel discussion with Philip P. Arnold, Tupac Enrique Acosta, Sandy Bigtree, Joe Heath, Betty Lyons, Tina Ngata.


## Details
- Christian Domination & The Genocide of Turtle Island
- 19 April 2023 at 5:00PM
- [CCUN Chapel, 777 United Nations Plaza, New York, NY 10017](https://goo.gl/maps/4FhC5h1QWsvojHxC7)
- Art by Analena Provost
- [Download the flyer as a PDF](/assets/pdfs/Christian-Domination-Event.pdf)

