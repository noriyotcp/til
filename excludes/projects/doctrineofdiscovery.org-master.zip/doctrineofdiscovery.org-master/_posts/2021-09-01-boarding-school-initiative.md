---
title: "U.S. Department of the Interior Indian Boarding School Initiative"
date: 2021-09-01T14:54:46
excerpt: "Read the Indian Boarding School Initiative document."
published: true
categories:
  - law
tags:
  - PDF
  - US
---
## 2021 June 22 Federal Indian Boarding School Initiative

[view the document as a PDF](/assets/pdfs/secint-memo-esb46-01914-federal-indian-boarding-school-truth-initiative-2021-06-22-final508-1.pdf)
