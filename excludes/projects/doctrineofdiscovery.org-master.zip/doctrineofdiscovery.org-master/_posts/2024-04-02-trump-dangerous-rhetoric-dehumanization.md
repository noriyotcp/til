---
title: "Trump’s Dangerous Rhetoric of Dehumanization"
categories:
  - Blog
tags:
  - link
  - Trump
  - immigration
  - dehumanization
link: https://goodfaithmedia.org/432273-2/
author: adam-dj-brett
---
> Civilization and personhood are the intellectual bulwarks for the justification of colonization. The colonizer assumes they are made in the image of their God while spreading the message of conquest, civilization and Christianity.
> 
> The [Doctrine of Discovery](https://doctrineofdiscovery.org/), a set of 15th-century papal bulls, provides the theological and legal framework for Christian domination. It communicates that "explorers" who "discover" lands not occupied by Christians can view them as "*terra nullis*"--a territory without a master--and claim them for their sovereign.