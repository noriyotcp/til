---
title: "Evangelical Covenant Church Repudiates the Doctrine of Discovery"
date: 2021-07-01T14:54:46
excerpt: "Read the Evangelical Covenant Churches statement repudiating the Doctrine of Discovery."
published: true
author: evangelical-covenant-church
categories:
  - Repudiations
  - Faith-Communities
tags:
  - Evangelical
  - Protestant
  - Christian
  - PDF
  - Repudiations
---
## Evangelical Covenant Church statement
> Delegates at the Covenant Annual Connection voted overwhelmingly (84%) on Friday (June 25) to approve a resolution acknowledging the damage done to Indigenous peoples in the Americas by taking their land and rights and lamenting the church’s complicity in the continuing effects of that history. [read more...](https://religionnews.com/2021/06/29/evangelical-covenant-church-joins-list-of-protestant-denominations-rebuking-doctrine-of-discovery/)

* [Download the 2021 Evangelical Covenant Church in Sweden's statement (⤓ PDF)](/assets/pdfs/Evangelical-Covenant-Church-35.-Resolution-to-Repudiate-the-Doctrine-of-Discovery.pdf "PDF")
* Read about the [Evangelical Covenant Church joining the list of Protestant denominations rebuking Doctrine of Discovery](https://religionnews.com/2021/06/29/evangelical-covenant-church-joins-list-of-protestant-denominations-rebuking-doctrine-of-discovery/) in this article by Emily McFarlan Miller for RNS.
