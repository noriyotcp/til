---
ID: 8964
title: "Unitarian Universalist Association of Congregations Repudiates the Doctrine of Discovery"
author: UUA
excerpt: "A Unitarian Universalist Resolution To Repudiate the Doctrine of Discovery, and Implement the UN Declaration on the Rights of Indigenous Peoples"
permalink: /unitarian-universalist-association-of-congregations/
published: true
date: 2018-07-28 02:39:39
categories:
  - Faith-Communities
  - Repudiations
tags:
  - Repudiations
  - Unitarian
  - Universalist
  - UUA
redirect_from:
  - /8964/
---

*   [A Unitarian Universalist Resolution To Repudiate the Doctrine of Discovery, and Implement the UN Declaration on the Rights of Indigenous Peoples (⤓ PDF download)](/assets/pdfs/UUofP-Resolution-012911.pdf)
*   [Motion from the Right Relationship Monitoring Committee for the UUA Board of Trustees meeting January 2012 (⤓ PDF download)](/assets/pdfs/UUofP-Resolution-012911.pdf)
*   [Why We Are Offering This Resolution at General Assembly 2012 (⤓ PDF download)](/assets/pdfs/uuaunresolution.pdf)
*   [2012 Responsive Resolution (⤓ PDF download)](/assets/pdfs/uuaunresolution.pdf)
