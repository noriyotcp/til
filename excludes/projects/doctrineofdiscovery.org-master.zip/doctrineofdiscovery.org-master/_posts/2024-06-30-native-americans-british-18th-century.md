---
title: "Native Americans and the British in the 18th century"
categories:
  - Blog
tags:
  - link
  - colonialism
  - TNA
  - The-National-Archive
link: https://beta.nationalarchives.gov.uk/explore-the-collection/explore-by-time-period/georgians/native-americans-18th-century/
---
While Britain's American Colonies grew, Native American tribes became increasingly reliant on European powers for trade goods, especially metal objects and firearms. Our records shed light on relations with the Creek nation and the Cherokee, for example, before and during the Revolutionary War.