---
ID: 8956
title: "United Church of Christ Repudiates the Doctrine of Discovery"
author: united-church-christ
excerpt: "Calling for the United Church of Christ to Repudiate the Doctrine of Discovery Which Authorized the Genocide of Native Peoples and the Theft of Native Lands."
permalink: /united-church-of-christ/
published: true
date: 2018-07-28 02:33:12
categories:
  - Faith-Communities
  - Repudiations
tags:
  - Repudiations
  - Christianity
  - UCC
  - United-Church-Christ
redirect_from:
  - /8956/
---

*   [Calling for the United Church of Christ to Repudiate the Doctrine of Discovery Which Authorized the Genocide of Native Peoples and the Theft of Native Lands (⤓ PDF download)](/assets/pdfs/ucc-gs29-1.pdf).
*   ["Educational Content and Documentary."](http://www.ucc.org/justice_racism_doctrine-of-discovery)
