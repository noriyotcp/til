---
title: "SU hosts conference on white supremacy 200 years after Johnson v. McIntosh ruling"
categories:
  - Blog
tags:
  - link
  - event
  - Conference
  - press
link: https://dailyorange.com/2023/12/su-hosts-conference-200-years-after-johnson-v-mcintosh-ruling/
---
Ilianna Murphy, a junior at Simpson College who attended the conference, said her biggest takeaway is the importance of listening more to Indigenous people and recognizing the privilege of colonizers.

“Basically, a foundation of everything that we have is based on Christian documents, the document on Christian discovery,” Murphy said. “(We) should be realizing that we should give our lands back, that it wasn’t our land in the first place.”
