---
title: "New Resources: Talking to Christians about the Doctrine of Discovery"
categories:
  - Blog
tags:
  - link
  - colonialism
  - doctrine-of-discovery
link: https://tinangata.substack.com/p/new-resources-talking-to-christians
author: tina-ngata
---
> Remember, if it’s starting to get heated, step out and take a breather, you can always have the kōrero again another day.
> TLDR: It’s ok to be Christian, it’s not ok to be Christian-supremacist.

follow the link to the download