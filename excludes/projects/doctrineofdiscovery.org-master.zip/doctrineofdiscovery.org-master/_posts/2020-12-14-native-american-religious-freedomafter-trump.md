---
title: "Native American Religious Freedom after Trump"
date: 2020-12-14T14:54:46
categories:
  - Blog
tags:
  - link
  - doctrine-discovery
  - religious-freedom
link: https://berkleycenter.georgetown.edu/responses/native-american-religious-freedom-after-trump
---
> We should note that from the perspective of Native Americans, religious freedom has never been a good tool.
