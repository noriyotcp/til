---
title: "Indigenous Craft Fair"
categories:
  - Blog
tags:
  - link
  - UN
  - UNPFII
  - WeAreIndigenous
link: https://aila.ngo/2024-craft-fair/
author: aila
---
We invite everyone to visit the Indigenous Peoples Craft Fair on 17 April 2024 from 9:00 AM to 3:00 PM on the Eighth Floor of the Church Center of the United Nations (CCUN) located at 777 United Nations Plaza, New York, NY 10017.

For Indigenous peoples wishing to serve as vendors, setup is done on a first-come, first-serve basis. Being a vendor in the craft fair is reserved for Indigenous peoples participating in the UNPFII.

The craft fair is cash only.

If you have questions, email aila@aila.ngo