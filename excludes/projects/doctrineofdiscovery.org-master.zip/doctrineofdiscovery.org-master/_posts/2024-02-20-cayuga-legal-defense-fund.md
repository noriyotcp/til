---
title: "Gayogohó:nǫ˺ (Cayuga) Legal Defense Fund Launches: Justice for an Indigenous People"
categories:
  - Blog
tags:
  - link
  - legal
  - fund
link: https://www.redlakenationnews.com/story/2024/02/13/news/gayogohn-legal-defense-fund-launches-justice-for-an-indigenous-people/120212.html
---
> Ithaca, NY- On Sunday, Feb 4th, over 400 Haudenosaunee and US citizens celebrated Gayogo̱hó꞉nǫʼ (Cayuga) culture, the local traditional community, and the new Gayogo̱hó꞉nǫʼ Legal Defense Fund. Indoors and out, people enjoyed Haudenosaunee food, music, and craftwork, as well as guest speakers and a documentary showing. US solidarity groups collaborated on this vibrant event with Gayogo̱hó꞉nǫʼ and other Haudenosaunee citizens, including from Onondaga Nation.