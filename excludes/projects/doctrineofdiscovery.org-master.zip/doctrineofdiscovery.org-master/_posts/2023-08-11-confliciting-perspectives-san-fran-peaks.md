---
title: "Conflicting Perspectives Regarding the Holy Mountain Called 'San Francisco Peaks,' and Other Sacred and Significant Places of Original Nations and Traditional Healers"
categories:
  - Blog
tags:
  - link
  - Post Formats
link: https://originalfreenations.com/conflicting-perspectives-regarding-the-holy-mountain-called-san-francisco-peaks-and-other-sacred-and-significant-places-of-original-nations-and-traditional-healers/
author: steven-newcomb
---

