---
title: "Political theology, discovery and the roots of the ‘great replacement’"
categories:
  - Blog
tags:
  - link
  - theology
  - discovery
link: https://doi.org/10.1177/03063968241238601
---

Bossen, C. (2024). Political theology, discovery and the roots of the ‘great replacement’. Race & Class, 0(0). <https://doi.org/10.1177/03063968241238601>.