---
ID: 9440
title: 'RNS article about the conference'
author: emily-mcfarlan-miller
excerpt: "The way Steven T. Newcomb describes the Doctrine of Discovery these days is 'a claim of a right of Christian domination.' It was first expressed by Pope Nicholas V in the 1452 papal bull Dum Diversas, which — along with subsequent bulls Romanus Pontifex and Inter Caetera — created a theological justification for Christian rulers seizing the property and possessions of non-Christians"
permalink: /rns-article-about-the-conference/
published: true
date: 2018-08-24 12:15:43
categories:
  - News
tags:
  - religion
  - News
  - RNS
---
> The way Steven T. Newcomb describes the Doctrine of Discovery these days is “a claim of a right of Christian domination.” It was first expressed by Pope Nicholas V in the 1452 papal bull “[Dum Diversas](/dum-Diversas/),” which — along with subsequent bulls [“Romanus Pontifex”](/the-bull-romanus-pontifex-nicholas-v/) and “[Inter Caetera](/inter-caetera/)” — created a theological justification for Christian rulers seizing the property and possessions of non-Christians.

[Read more @ Religion News Service](https://religionnews.com/2018/08/22/denominations-repent-for-native-american-land-grabs/)
