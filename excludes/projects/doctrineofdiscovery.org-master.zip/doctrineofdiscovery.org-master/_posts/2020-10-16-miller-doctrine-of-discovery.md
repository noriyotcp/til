---
title: "Indigenous Peoples, International Law, and Colonialism Lecture"
date: 2020-10-16T14:54:46
categories:
  - Blog
tags:
  - link
  - video
link: https://youtu.be/hYBh353_QWw
---
Robert J Miller, Professor of Law in the Sandra Day O'Connor College of Law at Arizona State University gave a lecture entitled "Indigenous Peoples, International Law, and Colonialism" at Washington State University for Indigenous Peoples Day 2020. One of the major points of this talk is the Doctrine of Discovery.
