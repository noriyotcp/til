---
title: "What Fifteenth-Century Papal Bulls Can Teach Us About Indigenous Identity"
date: 2020-12-13T14:54:46
categories:
  - Blog
tags:
  - link
  - doctrine-discovery
link: https://berkleycenter.georgetown.edu/responses/what-fifteenth-century-papal-bulls-can-teach-us-about-indigenous-identity
author: steven-newcomb
---
> Whether the intent of domination expressed by that language is part of “official Church teachings” is irrelevant in my view. What is relevant is that, throughout the world, the present-day context and conditions experienced by “Indigenous” nations and peoples is an outgrowth of the patterns of domination and dehumanization expressed in those many documents issued centuries ago by the Holy See.
