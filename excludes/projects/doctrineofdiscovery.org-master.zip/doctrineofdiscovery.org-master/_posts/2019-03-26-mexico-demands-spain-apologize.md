---
ID: 9537
title: "Mexico demands Spain apologize for colonial abuse of indigenous people"
author: adam-dj-brett
excerpt: "In letter to Spanish king, President Obrador cites massacres and oppression during conquest of Mexico."
permalink: /mexico-spain-colonial-abuse/
published: true
date: 2019-03-26 03:47:22
categories:
  - News
tags:
  - Indigenous-Peoples
  - Spain
  - Mexico
---

> “I have sent a letter to the king of Spain and another to the pope calling for a full account of the abuses and urging them to apologize to the indigenous peoples (of Mexico) for the violations of what we now call their human rights,” Lopez Obrador, 65, said in the video, which he posted to his social media accounts.

[Read More at the Guardian](https://www.theguardian.com/world/2019/mar/25/mexico-demands-spain-apology-colonialism-obrador?utm_term=Autofeed&CMP=fb_us&utm_medium=Social&utm_source=Facebook&fbclid=IwAR1tADVPGf15iVN8gRJQFEMv3npcfS1bYTUwUwpFLhvMYAjqz5VdLWbJZFs#Echobox=1553557292)
