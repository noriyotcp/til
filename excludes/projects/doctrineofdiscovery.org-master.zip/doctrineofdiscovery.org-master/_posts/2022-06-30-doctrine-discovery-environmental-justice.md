---
title: "What Fifteenth-Century Papal Bulls Can Teach Us About Indigenous Identity"
date: 2020-12-13T14:54:46
categories:
  - Blog
tags:
  - link
  - doctrine-discovery
link: https://thefield.asla.org/2020/01/30/what-does-the-doctrine-of-discovery-have-to-do-with-environmental-justice/
author: indigenous-values-initiative
---
>To really understand the American landscape, you need to know about the Doctrine of Discovery. As a set of principles used to justify European colonization, it grew over hundreds of years to become a pillar of international law, and it set the stage for centuries of imperialism worldwide.
