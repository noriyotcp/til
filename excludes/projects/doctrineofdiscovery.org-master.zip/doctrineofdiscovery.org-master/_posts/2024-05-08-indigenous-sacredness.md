---
title: "Indigenous Sacredness, Christendom and the Doctrine of Discovery"
categories:
  - Blog
tags:
  - link
  - doctrine-of-discovery
  - christianity
link: https://tinangata.com/2024/05/03/indigenous-sacredness-christendom-and-the-doctrine-of-discovery/
author: tina-ngata
--- 
> The conversation I am much more interested in, and that I feel is important to have – is an open, and frank conversation about the role Christianity has played, and still plays in colonisation, the impacts of that history, how it continues to draw privilege from colonialism, how it reckons with these facts, and what its place should be in an anticolonial future.

