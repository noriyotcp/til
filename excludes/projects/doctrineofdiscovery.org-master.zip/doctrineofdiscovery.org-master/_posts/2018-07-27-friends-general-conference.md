---
ID: 8946
title: "Friends General Conference Repudiates the Doctrine of Discovery"
author: indigenous-values-initiative
excerpt: "Minute on the Doctrine of Discovery, Approved July 25, 2012, New York Yearly Meeting Summer Sessions Silver Bay, New York"
permalink: /friends-general-conference/
published: true
date: 2018-07-27 22:40:26
last_modified_at: 2020-07-29 13:08:00
categories:
  - Faith-Communities
  - Repudiations
tags:
  - quakers
  - friends
  - repudiations
  - christianity
  - PDF
redirect_from:
  - /friends-general-conference/amp/
  - /friends-general-conference/
  - /8946/
---
*   [Minute on the Doctrine of Discovery, Approved July 25, 2012, New York Yearly Meeting Summer Sessions Silver Bay, New York (⤓  PDF Download)](/assets/pdfs/Minute_Doctrine_of_Discovery-ny.pdf)
*   [Baltimore Yearly Meeting (Religious Society of Friends) 2012, Indian Affairs Committee, Background Materials for Minute to Repudiate Doctrine of Discovery (⤓ PDF Download)](/assets/pdfs/Minute_Doctrine_of_Discovery-ny.pdf)
*   [A Minute to Repudiate the Doctrine of Discovery and to Affirm the U.N. Declaration on the Rights of Indigenous Peoples, Drafted by the Indigenous Peoples Concerns Committee, Approved by Boulder Friends Meeting on March 10, 2013 (⤓ PDF Download)](/assets/pdfs/Minute_Doctrine_of_Discovery-ny.pdf)
*   [Repudiating the Doctrine of Discovery: Some references and resources Prepared by Canadian Friends Service Committee March 2013 (⤓ PDF Download)](/assets/pdfs/Resources-on-the-Doctrine-of-Discovery-from-Canadian-Friends-Service-Committee.pdf)
*  [Canadian Friends Service Committee (Quakers) - Repudiation of the Doctrine of Discovery. 2013. (⤓  PDF Download)](/assets/pdfs/Canadian-Quakers-Doctrine-of-Discovery-minute-and-background-August-2013.pdf)
* [Quaker Indigenous Rights Committee - FAQs on the Doctrine of Discovery & Terra Nullius. 2015. (⤓  PDF Download)](/assets/pdfs/Quaker-FAQs-on-DoD-July-30-2015.pdf)

### Related:

*   [Quaker Indian Committee Disavows Doctrine of Discovery](/quaker-indian-committee-disavows-doctrine-of-discovery-affirms-declaration/)
*   [Quakers](/repudiations/faith-communities/quakers/)
* [Canadian Friends Service Committee (Quakers)](/repudiations/faith-communities/canadian-quakers/)
