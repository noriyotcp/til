---
title: "WTL Conversations [S3E15]: Robert P. Jones Conversation with Phil Arnold and Sandy Bigtree on the Mapping the Doctrine of Discovery Podcast"
categories:
  - Blog
tags:
  - link
  - event
  - Conference
  - press
link: https://www.whitetoolong.net/p/wtl-conversations-s3e15-my-conversation
---
