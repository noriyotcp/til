---
ID: 9314
title: "Doctrine of Discovery Short Film"
author: indigenous-values-initiative
permalink: /doctrine-of-discovery-short-film/
published: true
date: 2018-08-03 08:19:36
categories:
  - Resources
  - Education
  - Videos
tags:
  - videos
  - films
  - Education
  - resources
---

<div class="embed-responsive embed-responsive-16by9">
  <iframe width="640" height="360" src="https://www.youtube-nocookie.com/embed/V3gF7ULVrl4?controls=0&amp;" frameborder="0" allowfullscreen></iframe>
</div>

* [Doctrine of Discovery Short Film on Youtube](https://www.youtube.com/watch?v=V3gF7ULVrl4) 
* [The First Video in the _Digital Wampum_ series](https://youtu.be/2DofTnRhm5o)
