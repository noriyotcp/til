---
title: "Evangelical Lutheran Church In Canada In Mission For Others"
author: elcic-ca
date: 2022-06-27T15:54:46
excerpt: "Read the Evangelical Lutheran Church in Canada in Mission For Others's statement repudiating the Doctrine of Discovery."
published: true
categories:
  - Repudiations
  - Faith-Communities
tags:
  - Protestant
  - Presbyterian
  - Christian
  - Repudiations
  - Canada
---
## The 2015 ELCIC Resolution on the Doctrine of Discovery

[⤓ Download The Evangelical Lutheran Church in Canada: Doctrine of Discovery](/assets/pdfs/2015-ELCIC-DoctrineofDiscoveryMotionFINAL.pdf)

### Further Resources
* [Evangelical Lutheran Church in Canada: Indigenous Rights and Relationships Resources](https://elcic.ca/compassionate-justice-and-public-policy/indigenous-rights-relationships/)
