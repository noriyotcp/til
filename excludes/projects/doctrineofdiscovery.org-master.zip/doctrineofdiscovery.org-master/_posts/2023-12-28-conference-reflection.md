---
title: "Attendee Reflection: Conference: The Religious Origins of White Supremacy: Johnson v. M’Intosh and the Doctrine of Christian Discovery"
categories:
  - Blog
tags:
  - link
  - event
  - Conference
  - press
link: https://hurstassociates.blogspot.com/2023/12/conference-religious-origins-of-white.html
---
> I wanted to get some thoughts written in a place where I could share them, but this post only scratches the surface of what I heard and experienced.  One person likened the weekend as providing more information than an academic class and that is true. It was overwhelming.  And because there was so much to say and discuss, nearly every session ran long and every break was eliminated! Very full days!
> 
> I'm looking forward to talking with some folks I know who attended the conference and sharing what we learned. I think the more I talk about it, the more it will become working knowledge and the more I may find ways of helping to counter the harm done by the Doctrine of Christian Domination.