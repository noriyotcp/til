---
title: "The Urgency of Indigenous Values"
categories:
  - Blog
tags:
  - link
  - book
  - featured
link: https://press.syr.edu/supressbooks/5835/urgency-of-indigenous-values-the/
author: philip-arnold
---
Philip P. Arnold, *The Urgency of Indigenous Values,* (Syracuse: Syracuse University Press, 2023), ISBN: 9780815638087.