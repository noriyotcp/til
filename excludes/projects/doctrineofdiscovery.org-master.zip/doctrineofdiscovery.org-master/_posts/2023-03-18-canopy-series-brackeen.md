---
title: "Haaland v. Brackeen
and the Logic of Discovery"
excerpt_separator: "<!--more-->"
categories:
  - Blog
tags:
  - link
  - Canopy
  - Johnson
  - featured
link: https://canopyforum.org/2023/03/18/haaland-v-brackeen-and-the-logic-of-discovery/
date: 2023-03-18 01:54:46
author: danallyod
sidebar:
  - title: "Next Steps"
    image: /assets/images/colonial-contact.jpg
    image-alt: "Indigenous peoples on the left and European Christian colonizers on the right planting a cross. In the middle is Mother Earth."
    text: "Learn More about the Doctrine of Discovery"
    nav: next-steps 
---
> In this light, I fear that the *Brackeen* lawsuit is the first in a row of dominoes --- if the Court strikes down ICWA, everything else could soon go with it." So is *Brackeen* a case about race or about sovereignty? A reading through the lens of *Johnson v. M'Intosh* suggests that it is about both.