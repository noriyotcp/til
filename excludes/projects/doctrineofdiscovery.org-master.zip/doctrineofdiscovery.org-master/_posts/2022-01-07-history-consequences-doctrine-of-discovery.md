---
title: "Examining the History and Consequences of the Doctrine of Christian Discovery"
categories:
  - link
tags:
  - link
  - announcement
link: https://artsandsciences.syracuse.edu/news-all/news-from-2022/examining-the-history-and-consequences-of-the-doctrine-of-christian-discovery/
author: indigenous-values-initiative
---
We have just been awarded a Henry Luce Grant for a 3 year project examining the religious dimensions of the Doctrine of Christian Discovery.
