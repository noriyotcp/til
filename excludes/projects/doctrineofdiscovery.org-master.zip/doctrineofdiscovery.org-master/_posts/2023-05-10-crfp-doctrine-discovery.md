---
title: "CRFP: Indigenous Peoples express hope and concern at Vatican’s repudiation of Doctrine of Discovery"
categories:
  - Blog
tags:
  - link
  - news
link: https://wired868.com/2023/04/27/crfp-indigenous-people-express-hope-and-concern-at-vaticans-repudiation-of-doctrine-of-discovery/
---
Philip P Arnold, a professor of religious studies at Syracuse University and the founding director of Skä·noñh — Great Law of Peace Center, was interviewed on the Emancipation Support Committee’s radio show Indaba, on Wednesday 12 April, along with his wife Sandy Bigtree.

Their position is that: “the Vatican’s statement reads in part like an attempt at damage control” and that it, “falls short of the kind of full accountability required to heal past wounds”.

Additionally, they argue that it does not compare favourably with other Christian repudiations:  the Episcopalians 2009, the World Council of Churches 2012, and myriad other Roman Catholic bodies throughout the 2000’s.