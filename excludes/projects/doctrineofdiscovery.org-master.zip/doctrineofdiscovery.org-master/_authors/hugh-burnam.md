---
username: hugh-burnam
name: Hugh Burnam
bio: "Dr. Hugh Burnam, Hode'nhyahä:dye' is Mohawk, Wolf Clan from the Onondaga Nation. Hugh's research focuses broadly on social justice issues pertaining to Native students in the education system, including K-12 and higher education."
avatar: /assets/images/authors/hugh-burnam-headshot.png
links:
  - label: "Email"
    icon: "fas fa-fw fa-envelope-square"
    url: "mailto:hburnam23@gmail.com"
  - label: "Website"
    icon: "fab fa-fw fa-linkedin"
    url: "https://www.linkedin.com/in/hugh-burnam-phd-a8a9b257/"
---
