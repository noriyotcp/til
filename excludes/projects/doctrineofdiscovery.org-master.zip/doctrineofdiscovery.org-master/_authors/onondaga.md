---
username: onondaga
name: Onondaga Nation
bio: "The Onondaga Nation is a member of the Haudenosaunee (“People of the Long House”), an alliance of native nations united for hundreds of years by traditions, beliefs and cultural values."
avatar: /assets/images/authors/onondaga.jpg
links:
  - label: "Email"
    icon: "fas fa-fw fa-envelope-square"
    url: "mailto:admin@onondaganation.org"
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://www.onondaganation.org"
  - label: "Facebook"
    icon: "fab fa-fw fa-facebook-square"
    url: "https://facebook.com/onondageh"
  - label: "Twitter"
    icon: "fab fa-fw fa-twitter-square"
    url: "https://twitter.com/onondaganation"
---