---
username: dana-lloyd
name: Dana Lloyd
bio: "Assistant Professor of Global Interdisciplinary Studies, Affiliated Faculty, Center for Peace and Justice Education, Villanova University."
avatar: /assets/images/authors/DanaLloyd-headshot-150x150.jpg
links:
  - label: "Email"
    icon: "fas fa-fw fa-envelope-square"
    url: "mailto:dana.lloyd@villanova.edu"
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://www1.villanova.edu/university/liberal-arts-sciences/scholarship/centers/peace-justice/faculty/biodetail.html?mail=dana.lloyd@villanova.edu&xsl=bio_long"
  - label: "PoliticalTheology"
    icon: "fas fa-fw fa-landmark"
    url: "https://politicaltheology.com/author/danalloyd/"
redirect_from:
  - /authors/danalloyd/
---