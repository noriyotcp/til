---
username: church-brethren
name: Church of the Brethren
bio: "Continuing the work of Jesus. Peacefully. Simply. Together."
avatar: /assets/images/authors/cob.jpg
links:
  - label: "Email"
    icon: "fas fa-fw fa-envelope-square"
    url: "mailto:cobweb@brethren.org"
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://www.brethren.org/"
  - label: "Facebook"
    icon: "fab fa-fw fa-facebook-square"
    url: "https://www.facebook.com/churchofthebrethren"
  - label: "Twitter"
    icon: "fab fa-fw fa-twitter-square"
    url: "http://twitter.com/#!/ChoftheBrethren"
  - label: "Instagram"
    icon: "fab fa-fw fa-instagram"
    url: "http://instagram.com/chofthebrethren"
---
