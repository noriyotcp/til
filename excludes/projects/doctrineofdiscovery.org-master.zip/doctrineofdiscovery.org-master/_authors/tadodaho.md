---
username: tadodaho
name: "Tadodaho Sid Hill"
bio: "Spiritual Leader, Haudenosaunee Confederacy"
avatar: /assets/images/authors/tadodaho-sidney-hill.jpg
---