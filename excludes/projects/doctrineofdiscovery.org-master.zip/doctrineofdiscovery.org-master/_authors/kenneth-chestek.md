---
username: kenneth-chestek
name: "Kenneth Chestek"
bio: "Kenneth Chestek, Professor of Law, University of Wyoming College of Law."
avatar: /assets/images/authors/generic-account-6491185_1280-unsplash.png
---