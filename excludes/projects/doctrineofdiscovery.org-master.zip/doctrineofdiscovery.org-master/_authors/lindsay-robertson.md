---
username: lindsay-robertson
name: Lindsday Robertson
bio: "Professor Lindsay G. Robertson joined the law faculty in 1997.  He teaches courses in Federal Indian Law, Comparative and International Indigenous Peoples Law, Constitutional Law and Legal History and serves as Faculty Director of the Center for the Study of American Indian Law and Policy and Founding Director of the International Human Rights Law Clinic."
avatar: /assets/images/authors/robertson-cropped.jpg
links:
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://law.ou.edu/directory/lindsay-robertson" 
---
