---
username: jim-kent
name: Jim Kent
bio: "Freelance writer, radio producer, columnist"
avatar: /assets/images/authors/jkent.jpg
links:
  - label: "Twitter"
    icon: "fab fa-fw fa-twitter-square"
    url: "https://twitter.com/jimkentvfte"
redirect_from:
  - /authors/jkent/
---