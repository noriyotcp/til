---
username: christian-church-disciples-of-christ
name: "Christian Church (Disciples of Christ)"
bio: "A mainline Protestant denomination centered in the United States and Canada"
avatar: /assets/images/authors/doc.png
links:
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://disciples.org/"
redirect_from:
  - /authors/ccdoc/
---