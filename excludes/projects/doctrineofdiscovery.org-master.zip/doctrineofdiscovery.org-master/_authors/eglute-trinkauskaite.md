---
username: egulte-trinkauskaite
name: "Eglutė Trinkauskaitė"
bio: "CEglutė Trinkauskaitė is full time faculty in the department of Humanistic Studies at the Maryland Institute College of Art."
avatar: /assets/images/authors/egluteTrinkauskaite.jpg
links:
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://www.mica.edu/undergraduate-majors-minors/humanistic-studies-major/eglute-trinkauskaite/"
---