---
username: umc
name: "United Methodist Church"
bio: "The United Methodist Church is a global denomination of more than 12 million members around the world."
avatar: /assets/images/authors/umc.png
links:
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "http://www.umc.org/"
---