---
username: evangelical-covenant-church
name: "Evangelical Covenant Church"
bio: "We join God in God's mission to see more disciples among more populations in a more caring and just world."
avatar: /assets/images/authors/evangelical-covenant-church.png
links:
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://covchurch.org/"
---