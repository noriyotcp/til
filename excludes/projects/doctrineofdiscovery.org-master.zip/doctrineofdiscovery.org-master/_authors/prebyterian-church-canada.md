---
username: prebyterian-church-canada
name: "The Presbyterian Church in Canada"
bio: "The Presbyterian Church in Canada is a Presbyterian denomination, serving in Canada under this name since 1875."
avatar: /assets/images/authors/Presbyterian_Church_in_Canada_logo.png
links:
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://presbyterian.ca/justice/social-action/indigenous-justice/"
  - label: "Facebook"
    icon: "fab fa-fw fa-facebook"
    url: "https://www.facebook.com/pcconnect"
redirect_from:
  - /authors/prebyterian-ca/
---