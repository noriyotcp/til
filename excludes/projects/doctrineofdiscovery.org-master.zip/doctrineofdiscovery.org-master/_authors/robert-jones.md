---
username: robert-jones
name: "Robert P. Jones"
bio: "Robert P. Jones (he/him) is the president and founder of PRRI and a leading scholar and a New York Times bestselling author."
avatar: /assets/images/authors/robert-p-jones2.jpeg
links:
  - label: "PRRI"
    icon: "fas fa-fw fa-link"
    url: "https://www.prri.org/staff/robert-p-jones-ph-d/"
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://www.whitetoolong.net/"  
  - label: "Twitter"
    icon: "fab fa-fw fa-twitter-square"
    url: "https://twitter.com/@robertpjones"
  - label: "Facebook"
    icon: "fab fa-fw fa-facebook-square"
    url: "https://www.facebook.com/robertpjonesDC"
  - label: "Instagram"
    icon: "fab fa-fw fa-instagram"
    url: "https://www.instagram.com/robertpjonesdc/"
  - label: "LinkedIn"
    icon: "fab fa-fw fa-linkedin"
    url: "https://www.linkedin.com/in/robertpjones/"
---