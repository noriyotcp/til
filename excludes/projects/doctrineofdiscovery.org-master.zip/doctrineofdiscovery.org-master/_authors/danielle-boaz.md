---
username: danielle-boaz
name: Danielle Boaz
bio: "Danielle N. Boaz (she/her) is associate professor of Africana studies at the University of North Carolina at Charlotte, where she teaches courses on human rights, social justice, and the law."
avatar: /assets/images/authors/danielle-Boaz_512x640-1.jpg
links:
  - label: "Email"
    icon: "fas fa-fw fa-envelope-square"
    url: "mailto:dboaz@charlotte.edu"
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://africana.charlotte.edu/directory/danielle-boaz-phd"
  - label: "ICCRR"
    icon: "fas fa-fw fa-landmark"
    url: "https://religiousracism.org/"
---