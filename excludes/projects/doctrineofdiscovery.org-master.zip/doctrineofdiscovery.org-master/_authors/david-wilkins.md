---
username: david-wilkins
name: "David E. Wilkins, Ph.D. (Lumbee Nation)"
bio: "Claiborne Distinguished Professor of Leadership Studies & Native Studies, University of Richmond."
avatar: /assets/images/authors/generic-account-6491185_1280-unsplash.png
links:
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://jepson.richmond.edu/faculty/bios/dwilkins/"
---