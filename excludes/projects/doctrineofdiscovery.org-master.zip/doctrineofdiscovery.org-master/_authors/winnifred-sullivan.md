---
username: winifred-sullivan
name: "Winnifred Fallers Sullivan"
bio: "Winnifred Fallers Sullivan is professor of religious studies at Indiana University Bloomington."
avatar: /assets/images/authors/sullivan1.jpg
links:
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://religiousstudies.indiana.edu/about/faculty/sullivan-winnifred.html"
---