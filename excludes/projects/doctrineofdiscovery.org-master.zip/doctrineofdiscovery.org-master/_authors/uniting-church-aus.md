---
username: uniting-church-aus
name: "Uniting Church in Australia"
bio: "In 1977, three Australian Christian denominations joined to form the Uniting Church in Australia. After many years of prayerful discernment, the Congregational Union in Australia, the Methodist Church of Australasia and the Presbyterian Church of Australia came together."
avatar: /assets/images/authors/UCA-logo.png
links:
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://uniting.church/"
  - label: "Facebook"
    icon: "fab fa-fw fa-facebook"
    url: "https://www.facebook.com/UnitingChurchAu"
  - label: "Twitter"
    icon: "fab fa-fw fa-twitter-square"
    url: "https://www.twitter.com/UnitingChurchAu"
---