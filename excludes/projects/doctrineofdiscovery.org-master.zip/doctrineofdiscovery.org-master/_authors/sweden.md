---
username: sweden
name: "Uniting Church in Sweden"
bio: "Equmeniakyrkan /Uniting Church in Sweden is the union of Baptist Union of Sweden, United Methodist Church and Mission Covenant Church of Sweden."
avatar: /assets/images/authors/equmeniakyrkan_farg.jpg
links:
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://equmeniakyrkan.se/"
---