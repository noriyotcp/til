---
username: andrew-little
name: "Andrew Little"
bio: "Andrew Little is an associate professor of business law in the College of Business Administration at Abilene Christian University in Texas, where he also serves as associate dean. His research interests include corporate social responsibility, legal history, and land use and natural resource law."
avatar: /assets/images/authors/andrew-little-headshot.png
links:
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://acu.edu/faculty/andy-little/"
---
