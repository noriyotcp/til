---
username: suzan-harjo
name: Suzan Shown Harjo
bio: "Suzan Shown Harjo, Cheyenne & Hodulgee Muscogee, is a writer, curator and policy advocate, who has helped Native Peoples protect and recover sacred places and over one million acres of lands."
avatar: /assets/images/authors/ssharjo.jpg
redirect_from:
    - /authors/ssharjo/
---