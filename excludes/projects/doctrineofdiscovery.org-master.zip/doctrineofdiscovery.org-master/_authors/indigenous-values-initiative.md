---
username: indigenous-values-initiative
name: Indigenous Values Initiative
avatar: /assets/images/indigenousvalues-2020.png
links:
  - label: "Email"
    icon: "fas fa-fw fa-envelope-square"
    url: "mailto:info@indigenousvalues.org"
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://indigenousvalues.org"
  - label: "Facebook"
    icon: "fab fa-fw fa-facebook-square"
    url: "https://facebook.com/indigenousvalues"
  - label: "Facebook"
    icon: "fab fa-fw fa-facebook-square"
    url: "https://www.facebook.com/doctrineofdiscovery"
  - label: "Instagram"
    icon: "fab fa-fw fa-instagram"
    url: "https://instagram.com/indigenousvalues"
  - label: "Twitter"
    icon: "fab fa-fw fa-twitter-square"
    url: "https://twitter.com/indigenousvi"
  - label: "YouTube"
    icon: "fab fa-fw fa-youtube-square"
    url: "https://youtube.com/c/IndigenousValuesInitiative"
redirect_from:
  - /authors/admin/
---