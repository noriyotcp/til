---
username: alexandra-fay
name: "Alexandra Fay"
bio: "Alexandra Fay is the inaugural Richard M. Milanovich Fellow at the Native Nations Law & Policy Center of UCLA School of Law. She writes about federal Indian law, tribal sovereignty, and critical race theory."
avatar: /assets/images/authors/alexandra-fay-circle.png
links:
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://law.ucla.edu/faculty/faculty-profiles/alexandra-fay"
---