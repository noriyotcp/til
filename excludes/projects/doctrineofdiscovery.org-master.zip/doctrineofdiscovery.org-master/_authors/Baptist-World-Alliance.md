---
username: baptist-world-alliance
name: Baptist World Alliance
bio: "A global network of 51 million Baptists in 130 countries and territories unified by a mission to impact the world for Christ."
avatar: /assets/images/authors/BWAIcon.jpg
links:
  - label: "Email"
    icon: "fas fa-fw fa-envelope-square"
    url: "mailto:info@baptistworld.org"
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://www.baptistworld.org/"
  - label: "Facebook"
    icon: "fab fa-fw fa-facebook-square"
    url: "https://www.facebook.com/baptistworld"
  - label: "Twitter"
    icon: "fab fa-fw fa-twitter-square"
    url: "https://twitter.com/baptistworld"
  - label: "Instagram"
    icon: "fab fa-fw fa-instagram"
    url: "https://www.instagram.com/baptistworld/"
---
