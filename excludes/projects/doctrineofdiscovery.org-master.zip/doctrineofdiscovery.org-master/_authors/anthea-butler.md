---
username: anthea-butler
name: "Anthea Butler"
bio: "Anthea Butler is the Geraldine R. Segal Professor in American Social Thought and Chair of Religious Studies at the University of Pennsylvania"
avatar: /assets/images/authors/anthea-butler.jpg
links:
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://rels.sas.upenn.edu/people/anthea-butler"
---
