---
username: joao-chaves
name: João Chaves, Ph.D.
bio: "Associate Director for Programming Hispanic Theological Initiative and Assistant Professor of Religion Latinx Church Historical Studies, Department of Religion, Baylor University"
avatar: /assets/images/authors/Joao-Chaves2.jpg
links:
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://religion.artsandsciences.baylor.edu/person/joao-chaves-phd"
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://hti.ptsem.edu/joao-chaves/"
---