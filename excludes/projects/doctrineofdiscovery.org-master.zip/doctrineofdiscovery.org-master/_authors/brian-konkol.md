---
username: brian-konkol
name: Brian Konkol
bio: "The Rev. Brian Konkol serves as Dean of Hendricks Chapel and Professor of Practice at Syracuse University."
avatar: /assets/images/authors/Brian-Konkol2.jpg
links:
  - label: "Email"
    icon: "fas fa-fw fa-envelope-square"
    url: "mailto:chapel@syr.edu"
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://chancellor.syr.edu/university-leadership-2/chancellors-council/brian-konkol/"
---