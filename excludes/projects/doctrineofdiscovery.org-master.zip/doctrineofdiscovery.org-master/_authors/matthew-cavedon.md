---
username: matthew-cavedon
name: "Matthew P. Cavedon"
bio: "Matthew Cavedon is the Robert Pool Fellow in Law and Religion at Emory’s Center for the Study of Law and Religion. Previously a criminal defense attorney in Gainesville, GA, he graduated from Emory University in 2015 with a law degree and masters of theological studies."
avatar: /assets/images/authors/Matt_Cavedon_circle.png
---
