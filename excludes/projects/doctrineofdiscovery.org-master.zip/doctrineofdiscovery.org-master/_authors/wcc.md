---
username: wcc
name: "World Council of Churches"
bio: "A worldwide fellowship of churches seeking unity, a common witness and Christian service"
avatar: /assets/images/authors/wcc.gif
links:
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://www.oikoumene.org/en"
---