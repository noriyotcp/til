---
username: united-church-canada
name: "United Church of Canada"
bio: "The United Church of Canada is the largest Protestant denomination in Canada."
avatar: /assets/images/authors/united-church-canada.png
links:
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://www.united-church.ca/"
---