---
username: christian-reformed
name: "Christian Reformed Church"
bio: "A Protestant denomination in the United States and Canada"
avatar: /assets/images/authors/crc-logo.png
links:
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://www.crcna.org/"
---