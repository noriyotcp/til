---
username: peter-derrico
name: "Peter d&#8217;Errico"
bio: "Professor d'Errico continues to engage in law-related writing and consulting, primarily on issues of concern to indigenous peoples."
links:
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://blogs.umass.edu/derrico/"
  - label: "Substack"
    icon: "fas fa-fw fa-link"
    url: "https://peterderrico.substack.com/"
---