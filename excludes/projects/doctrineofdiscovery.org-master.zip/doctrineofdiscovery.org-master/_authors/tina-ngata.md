---
username: tina-ngata
name: "Tina Ngata"
bio: "Dismantling Frameworks of Domination, Rematriating Ways of Being."
avatar: /assets/images/authors/tina-ngata.png
links:
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://tinangata.com/"
  - label: "Patreon"
    icon: "fab fa-fw fa-patreon"
    url: "https://www.patreon.com/tinangata"
---