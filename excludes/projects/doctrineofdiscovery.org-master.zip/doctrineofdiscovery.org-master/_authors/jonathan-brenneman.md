---
username: jonathan-brenneman
name: "Jonathan Brenneman"
bio: "Jonathan is a Palestinian-American Christian and graduate of the Kroc Institute for International Peace Studies. He has worked in multiple countries doing Palestine advocacy, human rights monitoring, grassroots organizing, and challenging anti-Arab racism. Jonathan’s work connects the Palestinian decolonial struggle with those of other indigenous peoples, and challenges theologies of domination."
avatar: /assets/images/authors/jonathan-brenneman-sq-250x250.jpg
---