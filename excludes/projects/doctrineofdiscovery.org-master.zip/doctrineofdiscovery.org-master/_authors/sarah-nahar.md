---
username: sarah-nahar
name: "Sarah Nahar"
bio: "Sarah Nahar is a PhD student in Religion and Environmental Studies at Syracuse University and SUNY College of Environmental Science and Forestry, on unceded Onondaga land."
avatar: /assets/images/authors/sarah-nahar.jpeg
links:
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://syr.academia.edu/SarahNahar"
  - label: "Facebook"
    icon: "fab fa-fw fa-facebook"
    url: "https://www.facebook.com/sarah.elizabeth.2021/"
  - label: "Linkedin"
    icon: "fab fa-fw fa-linkedin"
    url: "https://www.linkedin.com/in/sarah-nahar-31996357/"
  - label: "Stir Up Peace"
    icon: "fas fa-fw fa-link"
    url: "https://www.mennonitemission.net/resources/peace/stir-up-peace" 
  - label: "Envirostory"
    icon: "fas fa-fw fa-link"
    url: "https://envirostorycny.com/" 
---


