---
username: episcopal-church
name: "Episcopal Church (USA)"
bio: "The Episcopal Church is a member church of the worldwide Anglican Communion based in the United States with dioceses elsewhere."
avatar: /assets/images/authors/ecusa.png
links:
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://www.episcopalchurch.org/"
redirect_from:
  - /authors/ecusa/
---