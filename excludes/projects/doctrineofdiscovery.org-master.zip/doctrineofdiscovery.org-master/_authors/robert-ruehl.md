---
username: robert-ruehl
name: "Robert Michael Ruehl"
bio: "Visiting Assistant Professor, Saint John Fisher College."
avatar: /assets/images/authors/rmruehl.jpg
links:
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://sjfc.academia.edu/RobertRuehl"
  - label: "LinkedIn"
    icon: "fab fa-fw fa-linkedin"
    url: "https://www.linkedin.com/in/robert-michael-ruehl-01a60817/"
redirect_from:
  - /authors/rmruehl/
---