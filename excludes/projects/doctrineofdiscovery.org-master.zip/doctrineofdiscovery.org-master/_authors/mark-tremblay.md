---
username: mark-tremblay
name: "Mark Tremblay"
bio: "Mark Tremblay is an ordained minister in The Presbyterian Church in Canada living in Calgary, AB. He has advanced degrees in Philosophy from the Claremont Graduate University and the University of Wales, Swansea."
avatar: /assets/images/authors/Mark-Tremblay-Headshot-1024x1024.png
---