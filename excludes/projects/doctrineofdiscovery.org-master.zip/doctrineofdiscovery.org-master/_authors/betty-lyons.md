---
username: betty-lyons
name: Betty Lyons
bio: "Betty Lyons, President & Executive Director of the American Indian Law Alliance (AILA), is an Indigenous and environmental activist and citizen of the Onondaga Nation."
avatar: /assets/images/authors/aila-logo.png
links:
  - label: "Email"
    icon: "fas fa-fw fa-envelope-square"
    url: "mailto:aila@aila.ngo"
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://aila.ngo"
  - label: "Facebook"
    icon: "fab fa-fw fa-facebook-square"
    url: "https://facebook.com/americanindianlawalliance"
  - label: "Twitter"
    icon: "fab fa-fw fa-twitter-square"
    url: "https://twitter.com/ailanyc"
redirect_from:
  - /authors/blyons
---