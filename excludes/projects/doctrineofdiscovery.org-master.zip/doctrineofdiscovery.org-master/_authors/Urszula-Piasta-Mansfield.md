---
username: Urszula-Piasta-Mansfield
name: "Urszula Piasta-Mansfield, Ph.D."
bio: "Associate Director, American Indian and Indigenous Studies Program."
avatar: /assets/images/authors/Urszula-Piasta-Mansfield-Cornell.jpg
links:
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://cals.cornell.edu/urszula-piasta-mansfield"
  - label: "Academia"
    icon: "fas fa-fw fa-link"
    url: "https://ulapiasta.academia.edu/"
---