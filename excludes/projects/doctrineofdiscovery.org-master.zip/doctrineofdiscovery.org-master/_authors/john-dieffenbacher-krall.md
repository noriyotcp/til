---
username: john-dieffenbacher-krall
name: John Dieffenbacher-Krall
bio: "Executive Director of the Wabanaki Alliance"
redirect_from:
    - /authors/jdk/
---