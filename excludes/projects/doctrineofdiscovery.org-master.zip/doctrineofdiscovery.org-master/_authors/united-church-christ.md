---
username: united-church-christ
name: "United Church of Christ"
bio: "The United Church of Christ (UCC) is a distinct and diverse community of Christians that come together as one church to join faith and action."
avatar: /assets/images/authors/united-church-christ.jpg
links:
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://www.ucc.org/"
---