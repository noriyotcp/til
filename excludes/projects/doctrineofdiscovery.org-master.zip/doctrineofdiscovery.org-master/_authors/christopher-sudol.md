---
username: christopher-sudol
name: "Christopher Sudol"
bio: "Christopher is a 2023 J.D. Candidate and Haub Scholar in the Elisabeth Haub School of Law at Pace University."
avatar: /assets/images/authors/Christopher-Sudol.jpg
links:
  - label: "Linkedin"
    icon: "fab fa-fw fa-linkedin"
    url: "https://www.linkedin.com/in/christophersudol/"
---