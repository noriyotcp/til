---
username: kerri-malloy
name: "Kerri J. Malloy"
bio: "Kerri J. Malloy is an Assistant Professor of Global Humanities and Special Advisor on Native American and Indigenous Studies to the Office of the Provost at San José State University. His research focuses on Indigenous genocide, healing, and reconciliation in North America and the necessity of systemic change within social structures to advance transitional justice."
avatar: /assets/images/authors/kerri-malloy.jpg
---

