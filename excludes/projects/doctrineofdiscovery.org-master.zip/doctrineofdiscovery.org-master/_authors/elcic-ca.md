---
username: elcic-ca
name: "Evangelical Lutheran Church In Canada In Mission For Others"
bio: "The Evangelical Lutheran Church in Canada is Canada's largest Lutheran denomination, with 95,000 baptized members in 519 congregations."
avatar: /assets/images/authors/elcic.ca.jpg
links:
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://elcic.ca/compassionate-justice-and-public-policy/indigenous-rights-relationships/"
  - label: "Facebook"
    icon: "fab fa-fw fa-facebook"
    url: "https://www.facebook.com/CanadianLutherans"
---