---
username: elca
name: "Evangelical Lutheran Church of America"
bio: "The Evangelical Lutheran Church in America (ELCA) is one of the largest Christian denominations in the United States, with about 4 million members in nearly 10,000 congregations across the United States, Puerto Rico and the U.S. Virgin Islands."
avatar: /assets/images/authors/elca.jpg
links:
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://www.elca.org/"
---