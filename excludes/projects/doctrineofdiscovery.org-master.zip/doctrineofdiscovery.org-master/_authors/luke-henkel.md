---
username: luke-henkel
name: "Luke Henkel"
bio: "Luke Henkel is an activist, a seeker, a healer, and a writer, among many other things. A recent MS graduate in Climate Justice, his focus has been on Indigenous spirituality and the healing that comes with institutionally dismantling the Doctrine of Discovery. He currently works with Laudato Si Movement as national programs coordinator."
avatar: /assets/images/authors/generic-account-6491185_1280-unsplash.png
---