---
username: tracy-basile
name: "Tracy Basile"
bio: "Tracy Basile teaches writing at Saint Thomas Aquinas College in New York and is writing a book about the lives of animals in American history."
avatar: /assets/images/authors/tracy-basile2.jpg
links:
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://muckrack.com/tracy-basile-1/portfolio"
---