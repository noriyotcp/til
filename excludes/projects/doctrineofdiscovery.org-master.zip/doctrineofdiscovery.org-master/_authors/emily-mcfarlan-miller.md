---
username: emily-mcfarlan-miller
name: "Emily McFarlan Miller"
bio: "Emily McFarlan Miller is a national reporter for RNS based in Chicago. She covers evangelical and mainline Protestant Christianity."
avatar: /assets/images/authors/emmiller.jpg
links:
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://religionnews.com/author/emiller/"
  - label: "Twitter"
    icon: "fab fa-fw fa-twitter-square"
    url: "https://twitter.com/emmillerwrites"
redirect_from:
  - /authors/emmiller
---