---
username: darle-wright-balfoort
name: Darle Wright Balfoort
bio: "Syracuse University Library Technician Department: Access and Resource Sharing, Business Unit: Academic Success"
avatar: /assets/images/authors/doctrineofdiscovery.org/assets/images/authors/Balfoort-Darle.16f475a9.fill-200x200.jpg
links:
  - label: "Email"
    icon: "fas fa-fw fa-envelope-square"
    url: "mailto:dwdoran@syr.edu"
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://library.syracuse.edu/staff/balfoort-darle/"
---
