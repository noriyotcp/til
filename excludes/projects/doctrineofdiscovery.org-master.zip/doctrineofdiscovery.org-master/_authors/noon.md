---
username: noon
name: "NOON"
bio: "Neighbors of Onondaga Nation."
avatar: /assets/images/authors/noon-Icon-smaller.jpg
links:
  - label: "Website"
    icon: "fas fa-fw fa-link"
    url: "https://www.peacecouncil.net/noon/"
  - label: "Facebook"
    icon: "fab fa-fw fa-facebook"
    url: "https://www.facebook.com/OnondagaNeighbors/"
---