## Donate today!

    Open Access Digital Humanities projects costs money to support. Please give to support our work on the Doctrine of Discovery so that we can continue to share, learn, and grow together. [Give today](/give/)
